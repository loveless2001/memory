# M4-SGM P2 pilot run — learned, N=16, seed=0

Label: **tiny-random-lm+taskhead** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.052 (53/1024) | 0.013 | 32.1 | 0.00771521722572413 |
| heldout_bank_derange | 0.008 (8/1024) | 0.005 | 32.1 | 0.007258988594557536 |
| heldout_coord_shuffle | 0.034 (35/1024) | 0.011 | 32.1 | 0.0077139661554509464 |
| heldout_read_offset | 0.018 (18/1024) | 0.008 | 32.1 | 0.6745910104364157 |
| heldout_query_off | 0.018 (18/1024) | 0.008 | 32.1 | None |
| train_split_none | 0.062 (16/256) | 0.029 | 32.0 | 0.007424876512232004 |

Chance = 0.0156. Wall seconds: 4361.
