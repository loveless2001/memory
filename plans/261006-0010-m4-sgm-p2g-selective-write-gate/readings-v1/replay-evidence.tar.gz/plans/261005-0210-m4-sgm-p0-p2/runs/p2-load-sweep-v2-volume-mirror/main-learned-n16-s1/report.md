# M4-SGM P2 pilot run — learned, N=16, seed=1

Label: **tiny-random-lm+taskhead** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.593 (607/1024) | 0.031 | 24.6 | 0.0008446603407602689 |
| heldout_bank_derange | 0.016 (16/1024) | 0.007 | 24.6 | 0.0011622698090447562 |
| heldout_coord_shuffle | 0.077 (79/1024) | 0.017 | 24.6 | 0.0008431684916809903 |
| heldout_read_offset | 0.016 (16/1024) | 0.007 | 24.6 | 0.696730162249878 |
| heldout_query_off | 0.022 (23/1024) | 0.009 | 24.6 | None |
| train_split_none | 0.582 (149/256) | 0.059 | 25.0 | 0.0012537262599505716 |

Chance = 0.0156. Wall seconds: 3315.
