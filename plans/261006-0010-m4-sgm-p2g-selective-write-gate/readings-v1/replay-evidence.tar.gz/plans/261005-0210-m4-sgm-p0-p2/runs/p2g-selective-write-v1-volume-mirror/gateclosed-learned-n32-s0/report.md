# M4-SGM P2 pilot run — learned, N=32, seed=0

Label: **tiny-random-lm+taskhead+DIAGNOSTIC-beta-bias-3** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.032 (33/1024) | 0.011 | 19.1 | 0.0003667670698591363 |
| heldout_bank_derange | 0.014 (14/1024) | 0.007 | 19.1 | 0.0005483269346305726 |
| heldout_coord_shuffle | 0.020 (20/1024) | 0.008 | 19.1 | 0.00036783198578430043 |
| heldout_read_offset | 0.015 (15/1024) | 0.007 | 19.1 | 0.720614415127784 |
| heldout_query_off | 0.018 (18/1024) | 0.008 | 19.1 | None |
| train_split_none | 0.031 (8/256) | 0.023 | 19.2 | 0.00048245044227562817 |

Chance = 0.0156. Wall seconds: 3539.
