# M4-SGM P2 pilot run — learned, N=16, seed=0

Label: **tiny-random-lm+taskhead+DIAGNOSTIC-beta-bias-3** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.797 (816/1024) | 0.023 | 20.6 | 0.000551855406096844 |
| heldout_bank_derange | 0.020 (20/1024) | 0.009 | 20.6 | 0.0013706317806256862 |
| heldout_coord_shuffle | 0.109 (112/1024) | 0.018 | 20.6 | 0.0006447372470548586 |
| heldout_read_offset | 0.016 (16/1024) | 0.008 | 20.6 | 0.7416521704290062 |
| heldout_query_off | 0.020 (20/1024) | 0.009 | 20.6 | None |
| train_split_none | 0.844 (216/256) | 0.044 | 21.0 | 0.0006221836595047686 |

Chance = 0.0156. Wall seconds: 2345.
