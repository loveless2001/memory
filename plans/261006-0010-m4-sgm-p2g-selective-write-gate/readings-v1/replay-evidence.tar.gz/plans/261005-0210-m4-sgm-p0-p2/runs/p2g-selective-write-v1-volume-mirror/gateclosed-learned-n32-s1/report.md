# M4-SGM P2 pilot run — learned, N=32, seed=1

Label: **tiny-random-lm+taskhead+DIAGNOSTIC-beta-bias-3** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.029 (30/1024) | 0.011 | 75.6 | 0.1310256012976243 |
| heldout_bank_derange | 0.015 (15/1024) | 0.007 | 75.6 | 0.1269278612531366 |
| heldout_coord_shuffle | 0.017 (17/1024) | 0.008 | 75.6 | 0.12998979224637885 |
| heldout_read_offset | 0.021 (22/1024) | 0.010 | 75.6 | 0.7584958402439952 |
| heldout_query_off | 0.018 (18/1024) | 0.009 | 75.6 | None |
| train_split_none | 0.039 (10/256) | 0.022 | 74.6 | 0.1513999334838445 |

Chance = 0.0156. Wall seconds: 3554.
