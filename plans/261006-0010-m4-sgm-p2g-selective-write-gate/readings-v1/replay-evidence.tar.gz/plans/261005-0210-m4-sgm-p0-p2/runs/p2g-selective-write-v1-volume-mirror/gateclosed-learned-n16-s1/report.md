# M4-SGM P2 pilot run — learned, N=16, seed=1

Label: **tiny-random-lm+taskhead+DIAGNOSTIC-beta-bias-3** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.797 (816/1024) | 0.026 | 16.4 | 0.0004971409716194586 |
| heldout_bank_derange | 0.016 (16/1024) | 0.007 | 16.4 | 0.0011621755202107335 |
| heldout_coord_shuffle | 0.129 (132/1024) | 0.021 | 16.4 | 0.0004920997278166084 |
| heldout_read_offset | 0.013 (13/1024) | 0.007 | 16.4 | 0.6538194776512682 |
| heldout_query_off | 0.016 (16/1024) | 0.007 | 16.4 | None |
| train_split_none | 0.797 (204/256) | 0.047 | 16.7 | 0.0010869735104285794 |

Chance = 0.0156. Wall seconds: 2323.
