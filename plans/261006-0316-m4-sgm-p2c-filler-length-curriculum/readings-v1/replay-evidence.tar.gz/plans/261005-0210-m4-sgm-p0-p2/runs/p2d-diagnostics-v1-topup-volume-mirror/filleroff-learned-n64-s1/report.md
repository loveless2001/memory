# M4-SGM P2 pilot run — learned, N=64, seed=1

Label: **tiny-random-lm+taskhead+DIAGNOSTIC-filler-off** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.013 (13/1024) | 0.007 | 133.6 | 0.06361618580331196 |
| heldout_bank_derange | 0.012 (12/1024) | 0.006 | 133.6 | 0.06900058288738364 |
| heldout_coord_shuffle | 0.012 (12/1024) | 0.006 | 133.6 | 0.0649564849577473 |
| heldout_read_offset | 0.014 (14/1024) | 0.007 | 133.6 | 0.12070296735328157 |
| heldout_query_off | 0.013 (13/1024) | 0.007 | 133.6 | None |
| train_split_none | 0.016 (4/256) | 0.015 | 134.8 | 0.06341392567856019 |

Chance = 0.0156. Wall seconds: 4630.
