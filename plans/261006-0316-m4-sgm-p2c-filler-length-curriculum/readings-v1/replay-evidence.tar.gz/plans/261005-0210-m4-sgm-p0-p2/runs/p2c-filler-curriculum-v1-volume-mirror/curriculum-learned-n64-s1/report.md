# M4-SGM P2 pilot run — learned, N=64, seed=1

Label: **tiny-random-lm+taskhead+DIAGNOSTIC-filler-len-schedule** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.014 (14/1024) | 0.007 | 121.8 | 0.0637486931004626 |
| heldout_bank_derange | 0.017 (17/1024) | 0.008 | 121.8 | 0.061486995471796035 |
| heldout_coord_shuffle | 0.018 (18/1024) | 0.008 | 121.8 | 0.06368595242336805 |
| heldout_read_offset | 0.016 (16/1024) | 0.007 | 121.8 | 0.3076917640864849 |
| heldout_query_off | 0.016 (16/1024) | 0.008 | 121.8 | None |
| train_split_none | 0.012 (3/256) | 0.013 | 123.5 | 0.060668572048598435 |

Chance = 0.0156. Wall seconds: 8694.
