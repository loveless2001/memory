# M4-SGM P2 pilot run — learned, N=32, seed=0

Label: **tiny-random-lm+taskhead+DIAGNOSTIC-filler-len-schedule** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.585 (599/1024) | 0.031 | 35.5 | 0.01585494467744317 |
| heldout_bank_derange | 0.023 (24/1024) | 0.009 | 35.5 | 0.017815161672933844 |
| heldout_coord_shuffle | 0.076 (78/1024) | 0.016 | 35.5 | 0.01217968769686267 |
| heldout_read_offset | 0.016 (16/1024) | 0.007 | 35.5 | 0.7787566091865301 |
| heldout_query_off | 0.017 (17/1024) | 0.008 | 35.5 | None |
| train_split_none | 0.637 (163/256) | 0.065 | 35.9 | 0.01077676056768695 |

Chance = 0.0156. Wall seconds: 2543.
