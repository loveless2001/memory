# M4-SGM P2 pilot run — learned, N=64, seed=0

Label: **tiny-random-lm+taskhead+DIAGNOSTIC-filler-len-schedule** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.019 (19/1024) | 0.008 | 178.1 | 0.08151023631580756 |
| heldout_bank_derange | 0.021 (21/1024) | 0.008 | 178.1 | 0.0818746793702303 |
| heldout_coord_shuffle | 0.019 (19/1024) | 0.008 | 178.1 | 0.0812091677544231 |
| heldout_read_offset | 0.015 (15/1024) | 0.007 | 178.1 | 0.2884303276659921 |
| heldout_query_off | 0.013 (13/1024) | 0.007 | 178.1 | None |
| train_split_none | 0.012 (3/256) | 0.013 | 181.5 | 0.07755721256580728 |

Chance = 0.0156. Wall seconds: 4917.
