# M4-SGM P2 pilot run — learned, N=32, seed=1

Label: **tiny-random-lm+taskhead+DIAGNOSTIC-filler-len-schedule** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.698 (715/1024) | 0.028 | 28.3 | 0.00017878694298271124 |
| heldout_bank_derange | 0.010 (10/1024) | 0.006 | 28.3 | 0.001029728479050581 |
| heldout_coord_shuffle | 0.084 (86/1024) | 0.017 | 28.3 | 0.00016448791303984734 |
| heldout_read_offset | 0.018 (18/1024) | 0.008 | 28.3 | 0.6985052030067891 |
| heldout_query_off | 0.015 (15/1024) | 0.007 | 28.3 | None |
| train_split_none | 0.711 (182/256) | 0.066 | 28.9 | 4.006736727624194e-05 |

Chance = 0.0156. Wall seconds: 2499.
