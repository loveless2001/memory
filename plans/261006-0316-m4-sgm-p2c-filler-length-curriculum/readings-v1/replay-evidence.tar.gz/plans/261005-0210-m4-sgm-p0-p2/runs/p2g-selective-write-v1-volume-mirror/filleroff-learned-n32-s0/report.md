# M4-SGM P2 pilot run — learned, N=32, seed=0

Label: **tiny-random-lm+taskhead+DIAGNOSTIC-filler-off** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.854 (875/1024) | 0.022 | 45.3 | 0.13504941338798382 |
| heldout_bank_derange | 0.017 (17/1024) | 0.008 | 45.3 | 0.1253142325565818 |
| heldout_coord_shuffle | 0.104 (107/1024) | 0.020 | 45.3 | 0.12002669125687682 |
| heldout_read_offset | 0.017 (17/1024) | 0.008 | 45.3 | 0.5448647984303534 |
| heldout_query_off | 0.015 (15/1024) | 0.007 | 45.3 | None |
| train_split_none | 0.883 (226/256) | 0.045 | 45.2 | 0.13926333604423036 |

Chance = 0.0156. Wall seconds: 2624.
