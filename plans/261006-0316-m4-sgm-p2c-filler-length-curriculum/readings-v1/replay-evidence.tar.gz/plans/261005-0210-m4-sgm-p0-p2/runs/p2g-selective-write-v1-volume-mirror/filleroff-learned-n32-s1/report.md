# M4-SGM P2 pilot run — learned, N=32, seed=1

Label: **tiny-random-lm+taskhead+DIAGNOSTIC-filler-off** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.801 (820/1024) | 0.024 | 30.6 | 0.010334483986896842 |
| heldout_bank_derange | 0.012 (12/1024) | 0.007 | 30.6 | 0.010174406473435482 |
| heldout_coord_shuffle | 0.098 (100/1024) | 0.017 | 30.6 | 0.0058659550056761 |
| heldout_read_offset | 0.014 (14/1024) | 0.007 | 30.6 | 0.4291207224596292 |
| heldout_query_off | 0.017 (17/1024) | 0.008 | 30.6 | None |
| train_split_none | 0.867 (222/256) | 0.041 | 30.5 | 0.009852558679361856 |

Chance = 0.0156. Wall seconds: 1902.
