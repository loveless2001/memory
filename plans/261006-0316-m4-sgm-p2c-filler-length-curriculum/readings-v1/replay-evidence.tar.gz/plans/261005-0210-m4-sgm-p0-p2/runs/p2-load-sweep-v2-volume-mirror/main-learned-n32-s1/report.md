# M4-SGM P2 pilot run — learned, N=32, seed=1

Label: **tiny-random-lm+taskhead** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.021 (22/1024) | 0.009 | 72.5 | 0.013259861901413622 |
| heldout_bank_derange | 0.014 (14/1024) | 0.007 | 72.5 | 0.011252579429132159 |
| heldout_coord_shuffle | 0.015 (15/1024) | 0.007 | 72.5 | 0.013333836948088984 |
| heldout_read_offset | 0.016 (16/1024) | 0.008 | 72.5 | 0.4265120510244742 |
| heldout_query_off | 0.017 (17/1024) | 0.008 | 72.5 | None |
| train_split_none | 0.039 (10/256) | 0.025 | 72.3 | 0.011798346682753147 |

Chance = 0.0156. Wall seconds: 4966.
