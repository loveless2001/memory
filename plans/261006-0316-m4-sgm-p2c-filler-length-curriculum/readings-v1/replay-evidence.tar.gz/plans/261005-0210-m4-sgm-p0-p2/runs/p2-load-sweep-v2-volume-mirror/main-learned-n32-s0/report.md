# M4-SGM P2 pilot run — learned, N=32, seed=0

Label: **tiny-random-lm+taskhead** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.021 (21/1024) | 0.008 | 56.8 | 0.007735174954185218 |
| heldout_bank_derange | 0.020 (20/1024) | 0.008 | 56.8 | 0.006028780478863516 |
| heldout_coord_shuffle | 0.019 (19/1024) | 0.008 | 56.8 | 0.007978853439143872 |
| heldout_read_offset | 0.013 (13/1024) | 0.007 | 56.8 | 0.4841493424028158 |
| heldout_query_off | 0.015 (15/1024) | 0.008 | 56.8 | None |
| train_split_none | 0.039 (10/256) | 0.022 | 56.6 | 0.005578238710853611 |

Chance = 0.0156. Wall seconds: 6267.
