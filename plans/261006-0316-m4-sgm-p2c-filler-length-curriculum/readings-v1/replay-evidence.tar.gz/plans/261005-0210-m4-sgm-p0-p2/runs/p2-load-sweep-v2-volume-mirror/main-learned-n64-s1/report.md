# M4-SGM P2 pilot run — learned, N=64, seed=1

Label: **tiny-random-lm+taskhead** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.018 (18/1024) | 0.008 | 160.4 | 0.07117027510093976 |
| heldout_bank_derange | 0.021 (21/1024) | 0.008 | 160.4 | 0.07260723614269793 |
| heldout_coord_shuffle | 0.012 (12/1024) | 0.006 | 160.4 | 0.07035025345385293 |
| heldout_read_offset | 0.020 (20/1024) | 0.009 | 160.4 | 0.25439187459414825 |
| heldout_query_off | 0.018 (18/1024) | 0.008 | 160.4 | None |
| train_split_none | 0.023 (6/256) | 0.018 | 162.3 | 0.09216247802396538 |

Chance = 0.0156. Wall seconds: 7721.
