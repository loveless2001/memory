# M4-SGM P2 pilot run — learned, N=64, seed=0

Label: **tiny-random-lm+taskhead** — mechanism evidence on a frozen RANDOM tiny backbone; not a pretrained/frozen-Qwen result.

| eval | accuracy | 95% half-width (episode) | eff. cells | query empty-read wt |
|---|---|---|---|---|
| heldout_none | 0.020 (20/1024) | 0.010 | 166.8 | 0.15430362824358212 |
| heldout_bank_derange | 0.016 (16/1024) | 0.007 | 166.8 | 0.1576448723399153 |
| heldout_coord_shuffle | 0.020 (20/1024) | 0.008 | 166.8 | 0.15539535460069942 |
| heldout_read_offset | 0.021 (22/1024) | 0.009 | 166.8 | 0.2562283396255225 |
| heldout_query_off | 0.018 (18/1024) | 0.008 | 166.8 | None |
| train_split_none | 0.016 (4/256) | 0.015 | 166.7 | 0.16248566712602042 |

Chance = 0.0156. Wall seconds: 8427.
